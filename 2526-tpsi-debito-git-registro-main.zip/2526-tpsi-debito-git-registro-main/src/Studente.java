package src;
import java.util.ArrayList;

public class Studente {

    private String nomeStudente;
    private String codice;
    private ArrayList<Integer> voti;

    public Studente(String nome, String matricola) {
        nomeStudente = nome;
        codice = matricola;
        voti = new ArrayList<>();
    }

    public void aggiungiVoto(int voto) {
        voti.add(voto);
    }

    public double calcolaMedia() {

        if (voti.isEmpty()) {
            return 0;
        }
        int totale = 0;
        for (int numero : voti) {
            totale = totale + numero;
        }
        return totale / voti.size();
    }

    public void StampaReport() {

        System.out.println("--- REPORT STUDENTE ---");
        System.out.println("Studente: " + nomeStudente);
        System.out.println("Codice: " + codice);
        System.out.println("Voti ottenuti: " + voti);
        System.out.println("Media voti: " + calcolaMedia());
    }
}