package src;

public class Main {
    public static void main(String[] args) {
        Studente primo = new Studente("Elena", "0000");
        primo.aggiungiVoto(9);
        primo.aggiungiVoto(7);

        Studente secondo = new Studente("Anna", "0001");
        secondo.aggiungiVoto(8);
        secondo.aggiungiVoto(6);

        Studente terzo = new Studente("Andrea", "0002");
        terzo.aggiungiVoto(4);
        terzo.aggiungiVoto(9);

        System.out.println("Media Elena: " + primo.calcolaMedia());
        System.out.println("Media Anna: " + secondo.calcolaMedia());
        System.out.println("Media Andrea: " + terzo.calcolaMedia());

        primo.StampaReport();
        secondo.StampaReport();
        terzo.StampaReport();
    }
}