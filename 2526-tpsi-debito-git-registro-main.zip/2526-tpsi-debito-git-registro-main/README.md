# REGISTRO STUDENTI
è un mini progetto Java per la gestione che semplifica la lista degli studenti e dei voti con l'utilizzo di GIt e GitHub.

# - contiene delle funzionalità:
* creazione di studenti
* aggiunta dei voti
* calcolo della media dei voti
* stampa il report dello studente

# - scopo:
    compilazione e esecuzione della classe Main

# - Git funzionalità:
* Branch feature/stampa-report
* Merge sul Main
* Commit con convenzione feat/docs/refactor
